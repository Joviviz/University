package br.uniceub.cc.pdm.base64codec;

import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Button btn_encode;
    private Button btn_decode;
    private EditText input_txt;
    private TextView output_txt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.base64_codec);

        btn_encode = findViewById(R.id.btn_encode);
        btn_decode = findViewById(R.id.btn_decode);
        input_txt = findViewById(R.id.input_txt);
        output_txt = findViewById(R.id.output_txt);

        btn_encode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String inputText = input_txt.getText().toString();
                String encodedText = encodeToBase64(inputText);
                output_txt.setText(encodedText);
            }
        });

        btn_decode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String encodedText = input_txt.getText().toString();
                String decodedText = decodeFromBase64(encodedText);
                output_txt.setText(decodedText);
            }
        });
    }


    private String encodeToBase64(String input) {
        if (input == null || input.isEmpty()) {
            return "";
        }
        return Base64.encodeToString(input.getBytes(), Base64.DEFAULT).trim();
    }


    private String decodeFromBase64(String encoded) {
        if (encoded == null || encoded.isEmpty()) {
            return "";
        }
        try {
            byte[] decodedBytes = Base64.decode(encoded, Base64.DEFAULT);
            return new String(decodedBytes);
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
            return "Error decoding Base64";
        }
    }
}
