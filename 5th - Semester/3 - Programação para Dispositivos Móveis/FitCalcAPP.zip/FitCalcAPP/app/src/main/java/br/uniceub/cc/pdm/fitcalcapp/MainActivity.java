package br.uniceub.cc.pdm.fitcalcapp;

import android.os.Bundle;
import android.transition.Scene;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.ViewAnimator;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // Views Tela Principal
    public Button btn_imc, btn_peso_ideal, btn_altura;

    // Views Tela IMC
    public Button tela_imc_btn_calcular, tela_imc_btn_voltar;
    public RadioGroup tela_imc_radio_group;
    public RadioButton tela_imc_radio_masculino, tela_imc_radio_feminino;
    public EditText tela_imc_txt_peso, tela_imc_txt_altura;
    public TextView tela_imc_txt_resultado;


    // Views Tela Peso Ideal
    public Button tela_peso_ideal_btn_calcular, tela_peso_ideal_btn_voltar;
    public RadioGroup tela_peso_ideal_radio_group;
    public RadioButton tela_peso_ideal_radio_masculino, tela_peso_ideal_radio_feminino;
    public EditText tela_peso_ideal_txt_altura;
    public TextView tela_peso_ideal_txt_resultado;

    // Views Tela Altura Ideal
    public Button tela_altura_ideal_btn_calcular, tela_altura_ideal_btn_voltar;
    public RadioGroup tela_altura_ideal_radio_group;
    public RadioButton tela_altura_ideal_radio_masculino, tela_altura_ideal_radio_feminino;
    public EditText tela_altura_ideal_txt_peso;
    public TextView tela_altura_ideal_txt_resultado;

    //Animacoes
    // calculadora_imc =Scene.getSceneForLayout(sceneRootFrameLayout, R.layout.calculadora_imc, this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        //
        CarregarTelaPrincipal();


    }

    public void CarregarTelaPrincipal(){
        setContentView(R.layout.tela_principal);

        btn_imc = findViewById(R.id.btn_imc);
        btn_peso_ideal = findViewById(R.id.btn_peso_ideal);
        btn_altura = findViewById(R.id.btn_altura);

        btn_imc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CarregarCalculadoraIMC();
            }
        });

        btn_peso_ideal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CarregarCalculadoraPesoIdeal();
            }
        });

        btn_altura.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CarregarCalculadoraAlturaIdeal();
            }
        });

    }

    public void CarregarCalculadoraIMC(){

        setContentView(R.layout.calculadora_imc);

        tela_imc_txt_peso = findViewById(R.id.tela_imc_txt_peso);
        tela_imc_txt_altura = findViewById(R.id.tela_imc_txt_altura);
        tela_imc_txt_resultado = findViewById(R.id.tela_imc_txt_resultado);
        tela_imc_btn_calcular = findViewById(R.id.tela_imc_btn_calcular);
        tela_imc_radio_masculino = findViewById(R.id.tela_imc_radio_masculino);
        tela_imc_radio_feminino = findViewById(R.id.tela_imc_radio_feminino);
        tela_imc_radio_group = findViewById(R.id.tela_imc_radio_group);

        // Calcular
        tela_imc_btn_calcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String alturaStr = tela_imc_txt_altura.getText().toString();
                String pesoStr = tela_imc_txt_peso.getText().toString();

                try {
                    float altura = Float.parseFloat(alturaStr);
                    float peso = Float.parseFloat(pesoStr);

                    float imc = peso / (altura * altura);

                    if (tela_imc_radio_masculino.isChecked())
                    {
                        if (imc <= 18.5){
                            tela_imc_txt_resultado.setText(String.format("IMC = %.2f \nClasse = Abaixo do peso", imc));

                        } else if (imc > 18.5 && imc < 24.9) {
                            tela_imc_txt_resultado.setText(String.format("IMC = %.2f \nClasse = Peso normal", imc));

                        } else if (imc >= 25.0 && imc < 29.9){
                            tela_imc_txt_resultado.setText(String.format("IMC = %.2f \nClasse = Pré-obesidade", imc));

                        } else if (imc >= 30.0 && imc < 34.9){
                            tela_imc_txt_resultado.setText(String.format("IMC = %.2f \nClasse = Obesidade Grau 1", imc));

                        } else if (imc >= 35.0 && imc < 39.9){
                            tela_imc_txt_resultado.setText(String.format("IMC = %.2f \nClasse = Obesidade Grau 2", imc));

                        } else {
                            tela_imc_txt_resultado.setText(String.format("IMC = %.2f \nClasse = Obesidade Grau 3", imc));

                        }
                    }
                    else if (tela_imc_radio_feminino.isChecked())
                    {
                        if (imc <= 18.5){
                            tela_imc_txt_resultado.setText(String.format("IMC = %.2f \nClasse = Abaixo do peso", imc));

                        } else if (imc >= 18.5 && imc < 26.9) {
                            tela_imc_txt_resultado.setText(String.format("IMC = %.2f \nClasse = Peso normal", imc));

                        } else if (imc >= 27.0 && imc < 32.9){
                            tela_imc_txt_resultado.setText(String.format("IMC = %.2f \nClasse = Pré-obesidade", imc));

                        } else if (imc >= 33.0 && imc < 37.9){
                            tela_imc_txt_resultado.setText(String.format("IMC = %.2f \nClasse = Obesidade Grau 1", imc));

                        } else if (imc >= 38.0 && imc < 44.9){
                            tela_imc_txt_resultado.setText(String.format("IMC = %.2f \nClasse = Obesidade Grau 2", imc));

                        } else {
                            tela_imc_txt_resultado.setText(String.format("IMC = %.2f \nClasse = Obesidade Grau 3"));

                        }
                    }
                } catch (NumberFormatException e) {
                    tela_imc_txt_resultado.setText("Por favor, insira valores válidos");
                }


            }
        });

        // Voltar
        tela_imc_btn_voltar = findViewById(R.id.tela_imc_btn_voltar);

        tela_imc_btn_voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CarregarTelaPrincipal();
            }
        });
    }

    public void CarregarCalculadoraPesoIdeal(){
        setContentView(R.layout.calculadora_peso_ideal);

        tela_peso_ideal_txt_altura = findViewById(R.id.tela_peso_ideal_txt_altura);
        tela_peso_ideal_txt_resultado = findViewById(R.id.tela_peso_ideal_txt_resultado);
        tela_peso_ideal_btn_calcular = findViewById(R.id.tela_peso_ideal_btn_calcular);
        tela_peso_ideal_radio_masculino = findViewById(R.id.tela_peso_ideal_radio_masculino);
        tela_peso_ideal_radio_feminino = findViewById(R.id.tela_peso_ideal_radio_feminino);
        tela_peso_ideal_radio_group = findViewById(R.id.tela_peso_ideal_radio_group);

        tela_peso_ideal_btn_calcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String alturaStr = tela_peso_ideal_txt_altura.getText().toString();
                try {
                    float altura = Float.parseFloat(alturaStr);
                    float peso_ideal = 0.0f;

                    if (tela_peso_ideal_radio_masculino.isChecked())
                    {
                        peso_ideal = 21.7f * (altura * altura);
                        tela_peso_ideal_txt_resultado.setText(String.format("Peso Ideal = %.2f kg", peso_ideal));

                    }
                    else if (tela_peso_ideal_radio_feminino.isChecked())
                    {
                        peso_ideal = 22.7f * (altura * altura);
                        tela_peso_ideal_txt_resultado.setText(String.format("Peso Ideal = %.2f kg", peso_ideal));
                    }
                } catch (NumberFormatException e) {
                    tela_peso_ideal_txt_resultado.setText("Por favor, insira valores válidos");
                }
            }
        });



        // Voltar
        tela_peso_ideal_btn_voltar = findViewById(R.id.tela_peso_ideal_btn_voltar);

        tela_peso_ideal_btn_voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CarregarTelaPrincipal();
            }
        });
    }

    public void CarregarCalculadoraAlturaIdeal(){
        setContentView(R.layout.calculadora_altura_ideal);

        tela_altura_ideal_txt_peso = findViewById(R.id.tela_altura_ideal_txt_peso);
        tela_altura_ideal_txt_resultado = findViewById(R.id.tela_altura_ideal_txt_resultado);
        tela_altura_ideal_btn_calcular = findViewById(R.id.tela_altura_ideal_btn_calcular);
        tela_altura_ideal_radio_masculino = findViewById(R.id.tela_altura_ideal_radio_masculino);
        tela_altura_ideal_radio_feminino = findViewById(R.id.tela_altura_ideal_radio_feminino);
        tela_altura_ideal_radio_group = findViewById(R.id.tela_altura_ideal_radio_group);

        tela_altura_ideal_btn_calcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String pesoStr = tela_altura_ideal_txt_peso.getText().toString();
                try {
                    float peso = Float.parseFloat(pesoStr);
                    float altura_ideal = 0.0f;

                    if (tela_altura_ideal_radio_masculino.isChecked())
                    {
                        altura_ideal =  (float) Math.sqrt(peso / 21.7f);
                        tela_altura_ideal_txt_resultado.setText(String.format("Sua altura ideal é : %.2f metros", altura_ideal));

                    }
                    else if (tela_altura_ideal_radio_feminino.isChecked())
                    {
                        altura_ideal = (float) Math.sqrt(peso / 22.7f);
                        tela_altura_ideal_txt_resultado.setText(String.format("Sua altura ideal é : %.2f metros", altura_ideal));
                    }
                } catch (NumberFormatException e) {
                    tela_altura_ideal_txt_resultado.setText("Por favor, insira valores válidos");
                }
            }
        });


        // Voltar
        tela_altura_ideal_btn_voltar = findViewById(R.id.tela_altura_ideal_btn_voltar);

        tela_altura_ideal_btn_voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CarregarTelaPrincipal();
            }
        });
    }




}
